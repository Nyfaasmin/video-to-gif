def transcribe_video(video_path, prompt):
    # Dummy transcript
    transcript = ["This is a motivational line.", "Another funny quote here."]
    # Dummy segments
    segments = [(0, 3), (4, 7)]
    return transcript, segments
